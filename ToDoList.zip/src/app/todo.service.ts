import { Injectable } from "@angular/core";
import { Itodo } from "./todo.model";

@Injectable({ providedIn: 'root' })
export class TodoList {
    constructor() { }

    listoftodos: Itodo[] = [];
    getlist() {
        return this.listoftodos;
    }

    addtodolist(task: Itodo) {
        this.listoftodos.push(task);
    }
    deleteTodo(index: number) {
        this.listoftodos.splice(index, 1);
    }
    updateTodoList(updatedTodos: Itodo[]): void {
        this.listoftodos = [...updatedTodos];
    }
}