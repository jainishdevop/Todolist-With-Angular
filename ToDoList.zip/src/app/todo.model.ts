export interface Itodo{
    task:string,
    completed:boolean
}