import { Component, OnInit } from '@angular/core';
import { TodoList } from '../todo.service';
import { Itodo } from '../todo.model';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-todolist',
  templateUrl: './todolist.component.html',
  styleUrls: ['./todolist.component.css']
})
export class TodolistComponent implements OnInit {

  form!: FormGroup;



  constructor(private todoservice: TodoList) { }

  listofDisplayTodo: Itodo[] = [];

  ngOnInit(): void {
    this.listofDisplayTodo = this.todoservice.getlist();
    this.form = new FormGroup({
      task: new FormControl(null, Validators.required),

    })
  }

  onAdd() {
    const listvalue = this.form.getRawValue();
    // give me code to clear form
    this.form.reset();
    this.todoservice.addtodolist({ ...listvalue, completed: false });
    this.listofDisplayTodo=this.todoservice.getlist();
   
  }

  onDeleteTodo(index: number) {
    console.log(index);
    this.todoservice.deleteTodo(index);
    this.listofDisplayTodo=this.todoservice.getlist();
    // this.todoservice.updateTodoList(this.listofDisplayTodo);
  }


  toggleComplete(index: number) {
    if (this.listofDisplayTodo[index]) {
      this.listofDisplayTodo[index].completed = !this.listofDisplayTodo[index].completed;
      this.todoservice.updateTodoList(this.listofDisplayTodo); // Update the service if needed
    }
  }

}
